from .tab import (
    MDTabsPrimary,
    MDTabsSecondary,
    MDTabsItem,
    MDTabsItemSecondary,
    MDTabsItemIcon,
    MDTabsItemText,
    MDTabsCarousel,
    MDTabsBadge,
)  # NOQA F401
